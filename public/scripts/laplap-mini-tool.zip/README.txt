﻿==============================================================
  LAP LAP MINI TOOL - Huong dan su dung
==============================================================

CAI NAO TRONG 2 FILE SAU CUNG CHAY DUOC:

  1. Double-click "laplap-mini-tool.bat"
     -> Tu dong goi PowerShell chay .ps1 (khong can setup gi).
     -> Khoi can doi ten file, khoi can doi extension.

  2. Double-click "laplap-mini-tool.ps1"
     -> Neu Windows hoi "How do you want to open this file?"
        -> Chon "Windows PowerShell".
     -> Neu bi loi "running scripts is disabled on this system":
        -> Mo PowerShell as Administrator, chay:
           Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass
        -> Sau do chay lai file .ps1.

LUU Y:
  - 2 file phai o CUNG 1 FOLDER (file .bat goi file .ps1 cung duong dan).
  - Tool can ket noi internet de gui ket qua len server LapLap.
  - Tool can quyen Administrator de doc mot so thong so phan cung (SMART, etc.).
  - Ket qua se tu mo trinh duyet tai: /test-laptop?highlight=<laptop_id>
FURMARK PORTABLE:
  - Folder FurMark_win64 da duoc bundle san trong ZIP.
  - Tool se tu detect va su dung, khong can download gi them.


NEU GAP LOI:
  - Mo "Windows PowerShell" thu cong (Start menu -> go "powershell").
  - Chay lenh:
      powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\admin\Documents\code ne\laplap-laptop\laplap-mini-tool.ps1"
  - Xem thong bao loi cu the, chup man hinh gui cho admin.

Build: 2026-10-12 22:21
